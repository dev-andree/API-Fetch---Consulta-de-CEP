let cep = window.document.getElementById("cep");
let botao = window.document.getElementById("botao");
let resposta = window.document.getElementById("resposta");
botao.addEventListener("click", clicar);

function clicar(){
    let valorCep = cep.value;
    const url = `https://viacep.com.br/ws/${valorCep}/json/`;
    
    fetch(url)
    .then(response => response.json())
    .then(dados => {
        resposta.innerHTML += JSON.stringify(dados);
    });

    /*.catch(error => {

    });*/
}
